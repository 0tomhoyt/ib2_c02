public class StockWarning {
}
