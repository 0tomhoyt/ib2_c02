import javax.swing.*;

public class Logout extends JFrame {
    public Logout(String title){
        super(title);

    }
}
